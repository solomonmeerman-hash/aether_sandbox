# 🌌 AetherSandbox

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)

An interactive, real-time particle physics and gravity field simulator running at 60 FPS on HTML5 Canvas.

## ✨ Features
- **3 Physics Modes:** Switch between gravitational attraction, shockwave repulsion, and orbital vortexes.
- **4 Color Palettes:** Cyberpunk, Solar Flare, Emerald Matrix, and Monochrome.
- **Interactive Spawning:** Click anywhere on the canvas to trigger high-velocity particle bursts.
- **Zero Dependencies:** Pure HTML, CSS, and ES6+ JavaScript—runs natively in any browser.

## 🎮 Controls
| Action | Effect |
| :--- | :--- |
| **Move Cursor** | Applies active physics force field to nearby particles |
| **Click Canvas** | Spawns a burst of 35 particles at the cursor |
| **HUD Panel** | Adjust physics mode, color theme, and total particle count |

## 🚀 Quick Start
Clone the repository and open `index.html` in your browser:

```bash
git clone https://github.com/YOUR_USERNAME/aether-sandbox.git
cd aether-sandbox
```
