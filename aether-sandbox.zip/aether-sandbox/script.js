const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

const modeSelect = document.getElementById("mode");
const themeSelect = document.getElementById("theme");
const countSlider = document.getElementById("count");
const countVal = document.getElementById("count-val");
const statsEl = document.getElementById("stats");
const burstBtn = document.getElementById("burst-btn");
const resetBtn = document.getElementById("reset-btn");
const controlsPanel = document.getElementById("controls");

const THEMES = {
  cyberpunk: ["#00f5d4", "#00bbf9", "#9b5de5", "#f15bb5"],
  solar: ["#ffbe0b", "#fb5607", "#ff006e", "#ff9e00"],
  emerald: ["#10b981", "#34d399", "#059669", "#a7f3d0"],
  mono: ["#f8fafc", "#cbd5e1", "#94a3b8", "#64748b"]
};

let width = (canvas.width = window.innerWidth);
let height = (canvas.height = window.innerHeight);
let particles = [];
let currentTheme = "cyberpunk";

const mouse = { x: width / 2, y: height / 2, active: false };

class Particle {
  constructor(x, y, burst = false) {
    this.x = x ?? Math.random() * width;
    this.y = y ?? Math.random() * height;
    const angle = Math.random() * Math.PI * 2;
    const speed = burst ? Math.random() * 7 + 2 : Math.random() * 1.5;
    this.vx = Math.cos(angle) * speed;
    this.vy = Math.sin(angle) * speed;
    this.radius = Math.random() * 2.2 + 1.1;
    this.pickColor();
  }

  pickColor() {
    const palette = THEMES[currentTheme];
    this.color = palette[Math.floor(Math.random() * palette.length)];
  }

  update() {
    if (mouse.active) {
      const dx = mouse.x - this.x;
      const dy = mouse.y - this.y;
      const dist = Math.hypot(dx, dy) || 1;
      const maxDist = 280;

      if (dist < maxDist) {
        const force = (1 - dist / maxDist) * 0.65;
        const mode = modeSelect.value;

        if (mode === "attract") {
          this.vx += (dx / dist) * force;
          this.vy += (dy / dist) * force;
        } else if (mode === "repel") {
          this.vx -= (dx / dist) * force * 1.8;
          this.vy -= (dy / dist) * force * 1.8;
        } else if (mode === "orbit") {
          this.vx += (-dy / dist) * force * 1.4 + (dx / dist) * (force * 0.22);
          this.vy += (dx / dist) * force * 1.4 + (dy / dist) * (force * 0.22);
        }
      }
    }

    this.vx *= 0.985;
    this.vy *= 0.985;
    this.x += this.vx;
    this.y += this.vy;

    if (this.x < 0 || this.x > width) {
      this.vx *= -0.9;
      this.x = Math.max(0, Math.min(width, this.x));
    }
    if (this.y < 0 || this.y > height) {
      this.vy *= -0.9;
      this.y = Math.max(0, Math.min(height, this.y));
    }
  }

  draw() {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.fill();
  }
}

function initParticles(count) {
  particles = Array.from({ length: count }, () => new Particle());
}

function spawnBurst(x, y, amount = 35) {
  for (let i = 0; i < amount; i++) {
    particles.push(new Particle(x, y, true));
  }
  if (particles.length > 1500) {
    particles.splice(0, particles.length - 1500);
  }
  countVal.textContent = particles.length;
}

window.addEventListener("resize", () => {
  width = canvas.width = window.innerWidth;
  height = canvas.height = window.innerHeight;
});

window.addEventListener("mousemove", (e) => {
  mouse.x = e.clientX;
  mouse.y = e.clientY;
  mouse.active = true;
});

window.addEventListener("mouseleave", () => {
  mouse.active = false;
});

canvas.addEventListener("click", (e) => {
  spawnBurst(e.clientX, e.clientY);
});

controlsPanel.addEventListener("click", (e) => e.stopPropagation());

themeSelect.addEventListener("change", (e) => {
  currentTheme = e.target.value;
  particles.forEach((p) => p.pickColor());
});

countSlider.addEventListener("input", (e) => {
  const target = Number(e.target.value);
  countVal.textContent = target;
  while (particles.length < target) particles.push(new Particle());
  if (particles.length > target) particles.length = target;
});

burstBtn.addEventListener("click", () => spawnBurst(width / 2, height / 2, 60));

resetBtn.addEventListener("click", () => {
  const target = Number(countSlider.value);
  countVal.textContent = target;
  initParticles(target);
});

let lastTime = performance.now();
let frames = 0;
let fps = 60;

function animate(now) {
  frames++;
  if (now - lastTime >= 500) {
    fps = Math.round((frames * 1000) / (now - lastTime));
    statsEl.textContent = `${fps} FPS • ${particles.length} pts`;
    frames = 0;
    lastTime = now;
  }

  ctx.fillStyle = "rgba(7, 7, 13, 0.2)";
  ctx.fillRect(0, 0, width, height);

  for (let i = 0; i < particles.length; i++) {
    particles[i].update();
    particles[i].draw();
  }

  requestAnimationFrame(animate);
}

initParticles(Number(countSlider.value));
requestAnimationFrame(animate);
